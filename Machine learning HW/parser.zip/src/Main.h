#include <string>

#ifndef MAIN_
#define MAIN_

int loadFormat(string path);
int loadData(string path);

#endif
